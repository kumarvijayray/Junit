package com.junit;

import java.util.List;
import java.util.Optional;

import javax.activation.DataSource;

import org.assertj.core.api.Assertions;
import org.junit.Test;
import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.TestMethodOrder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.jdbc.core.JdbcTemplate;

import com.junit.entity.Employee;
import com.junit.repository.EmployeeRepository;

@DataJpaTest
//@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
public class EmployeeRepositoryTests {
	
	@Autowired
	private EmployeeRepository employeeRepository;
	
	@Autowired
	private JdbcTemplate jdbcTemplate;
  
	@Autowired
	private DataSource dataSource;
	
	//JUnit test for saveEmployee
	
	@Test
	@Order(1)
	public void saveEmployeeTest() {
		
		Employee employee = Employee.builder()
				.firstName("Vijay")
				.lastName("Ray")
				.email("vray@gmail.com")
				.build();
		
		
		employeeRepository.save(employee);
		
		Assertions.assertThat(employee.getId()).isGreaterThan(0);
	}
	
	@Test
	public void getEmployeeTest() {
		Employee employee = employeeRepository.findById(1L).get();
		Assertions.assertThat(employee.getId()).isEqualTo(1L);
	}
	
	@Test
	public void getListOfEmployeesTest() {
		List<Employee> employees = employeeRepository.findAll();
		Assertions.assertThat(employees.size()).isGreaterThan(0);
	}
	@Test
	public void updateEmployeesTest() {
		Employee employee = employeeRepository.findById(1L).get();
		Assertions.assertThat(employee.getId()).isEqualTo(1L);
	}
	@Test
	public void updateEmployeeTest() {
		Employee employee = employeeRepository.findById(1L).get();
		employee.setEmail("vray@gmail.com");
		
		Employee employeeUpdated = employeeRepository.save(employee);
		Assertions.assertThat(employeeUpdated.getEmail()).isEqualTo("vray@gmail.com");
		
	}
	
	@Test
	public void deleteEmployeeTest() {
		
		Employee employee = employeeRepository.findById(1L).get();
		employeeRepository.delete(employee);
		Employee employee1 = null;
		
		Optional<Employee>optionalEmployee = employeeRepository.findByEmail("vray@gmail.com");
		if(optionalEmployee.isPresent()) {
			employee1 =optionalEmployee.get();
			
		}
		
		Assertions.assertThat(employee1).isNull();
	}
	
	
	

}
